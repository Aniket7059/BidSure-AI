import pytest
import app.models  # Ensures all ORM models are imported & registered
from app.database.base import Base
from app.database.session import engine


@pytest.fixture(autouse=True, scope="function")
def setup_test_database():
    """
    Automatically ensure all SQL database tables exist before running each test function.
    """
    Base.metadata.create_all(bind=engine)
    yield
