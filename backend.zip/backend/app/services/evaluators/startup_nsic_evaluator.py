from app.core.taxonomy import RequirementType
from app.schemas.compliance_evaluation import (
    ComplianceEvaluationRequest,
    ComplianceEvaluationResult,
)
from app.schemas.document_extraction import get_extracted_fields
from app.services.evaluators.base import RequirementEvaluator


class StartupNSICEvaluator(RequirementEvaluator):
    """
    Evaluates Startup India / NSIC registration and waiver eligibility.
    """

    @property
    def requirement_type(self) -> str:
        return RequirementType.STARTUP_INDIA.value

    def evaluate(
        self,
        request: ComplianceEvaluationRequest,
    ) -> ComplianceEvaluationResult:
        extracted_data = request.extracted_data or {}
        verification_data = request.verification_data or {}
        fields = get_extracted_fields(extracted_data)

        if not extracted_data and not verification_data:
            return ComplianceEvaluationResult(
                status="REVIEW",
                reason="No Startup India / NSIC registration evidence available.",
                evidence={},
            )

        reg_number = (
            verification_data.get("registration_number")
            or fields.get("registration_number")
        )
        emd_exemption = verification_data.get("emd_exemption_eligible", True)
        v_cfg = self.get_validation_config(request)
        require_emd = v_cfg.get("require_emd_exemption", False)

        if require_emd and not emd_exemption:
            return ComplianceEvaluationResult(
                status="FAIL",
                reason="Vendor does not satisfy tender requirement for EMD exemption eligibility.",
                evidence={
                    "registration_number": reg_number,
                    "emd_exemption_eligible": emd_exemption,
                },
            )

        if reg_number or verification_data:
            return ComplianceEvaluationResult(
                status="PASS",
                reason="Startup India / NSIC recognition verified. EMD & exemption criteria satisfied.",
                evidence={
                    "registration_number": reg_number,
                    "scheme_type": verification_data.get("scheme_type"),
                    "emd_exemption_eligible": emd_exemption,
                },
            )

        return ComplianceEvaluationResult(
            status="REVIEW",
            reason="Startup India / NSIC evidence requires officer review.",
            evidence=extracted_data,
        )
