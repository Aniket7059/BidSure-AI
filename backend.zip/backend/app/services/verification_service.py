from sqlalchemy.orm import Session

from app.providers.registry import ProviderRegistry, provider_registry
from app.providers.schemas import VerificationRequest, VerificationResult
from app.repositories.bid_document_repository import bid_document_repository
from app.repositories.bid_submission_repository import bid_submission_repository
from app.repositories.verification_result_repository import (
    verification_result_repository,
)


class VerificationService:
    """Coordinates provider execution and persistence.

    Providers retrieve/verify facts. This service connects those providers to
    BidSure's database while keeping provider implementations independent of
    SQLAlchemy and bid-specific identifiers.
    """

    def __init__(self, registry: ProviderRegistry | None = None) -> None:
        self.registry = registry or provider_registry

    def verify(
        self,
        db: Session,
        bid_submission_id: int,
        request: VerificationRequest,
        bid_document_id: int | None = None,
    ) -> VerificationResult:
        submission = bid_submission_repository.get_by_id(
            db,
            bid_submission_id,
        )
        if submission is None:
            raise ValueError(
                f"Bid submission not found: {bid_submission_id}"
            )

        if bid_document_id is not None:
            document = bid_document_repository.get_by_id(
                db,
                bid_document_id,
            )
            if document is None:
                raise ValueError(
                    f"Bid document not found: {bid_document_id}"
                )
            if document.bid_submission_id != bid_submission_id:
                raise ValueError(
                    "Bid document does not belong to the specified "
                    "bid submission."
                )

        provider = self.registry.get(request.verification_type)
        if provider is None:
            raise ValueError(
                "No verification provider registered for type: "
                f"{request.verification_type}"
            )

        result = provider.verify(request)

        verification_result_repository.create(
            db=db,
            bid_submission_id=bid_submission_id,
            bid_document_id=bid_document_id,
            result=result,
        )

        return result


verification_service = VerificationService()
