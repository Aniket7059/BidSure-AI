from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.models.compliance_assessment import ComplianceAssessment
from app.repositories.compliance_assessment_repository import (
    compliance_assessment_repository,
)
from app.repositories.compliance_check_repository import (
    compliance_check_repository,
)
from app.repositories.tender_requirement_repository import (
    tender_requirement_repository,
)
from app.schemas.compliance_assessment import (
    ComplianceAssessmentCreate,
    ComplianceAssessmentUpdate,
)
from app.services.compliance_service import (
    compliance_service,
)


class ComplianceAssessmentService:
    """
    Generates an overall compliance assessment for a bid submission.

    Task 8 Implementation:
    - Triggers evaluation of ALL tender requirements for the submission.
    - Summarizes PASS, FAIL, MISSING, NOT_APPLICABLE, and REVIEW checks.
    - Ensures mandatory requirement failures/missing evidence drive NON_COMPLIANT status & HIGH risk.
    - Ensures optional requirements (NOT_APPLICABLE) do not incorrectly cause disqualification.
    """

    def assess_submission(
        self,
        db: Session,
        bid_submission_id: int,
    ) -> ComplianceAssessment:

        # --------------------------------------------------
        # 1. Evaluate all tender requirements for submission
        # --------------------------------------------------

        compliance_service.evaluate_submission(
            db,
            bid_submission_id,
        )

        # --------------------------------------------------
        # 2. Retrieve resulting compliance checks
        # --------------------------------------------------

        checks = (
            compliance_check_repository.get_by_submission(
                db,
                bid_submission_id,
            )
        )

        # --------------------------------------------------
        # 3. Handle no compliance checks
        # --------------------------------------------------

        if not checks:

            assessment_data = ComplianceAssessmentCreate(
                bid_submission_id=bid_submission_id,
                score=None,
                risk_level=None,
                recommendation=None,
                status="PENDING",
                summary=(
                    "No compliance checks are available "
                    "for this bid submission."
                ),
                assessment_metadata={
                    "total_checks": 0,
                    "passed": 0,
                    "failed": 0,
                    "missing": 0,
                    "not_applicable": 0,
                    "review": 0,
                    "pending": 0,
                },
                assessed_at=None,
            )

            latest_assessment = (
                compliance_assessment_repository.get_latest_by_submission(
                    db, bid_submission_id
                )
            )
            if latest_assessment:
                update_data = ComplianceAssessmentUpdate(
                    score=None,
                    risk_level=None,
                    status="PENDING",
                    summary=assessment_data.summary,
                    assessment_metadata=assessment_data.assessment_metadata,
                    assessed_at=None,
                )
                return compliance_assessment_repository.update(
                    db, latest_assessment, update_data
                )

            return compliance_assessment_repository.create(
                db,
                assessment_data,
            )

        # --------------------------------------------------
        # 4. Count compliance check statuses
        # --------------------------------------------------

        total_checks = len(checks)

        passed = sum(
            1 for check in checks if check.status.upper() == "PASS"
        )
        failed = sum(
            1 for check in checks if check.status.upper() == "FAIL"
        )
        missing = sum(
            1 for check in checks if check.status.upper() == "MISSING"
        )
        not_applicable = sum(
            1 for check in checks if check.status.upper() == "NOT_APPLICABLE"
        )
        review = sum(
            1 for check in checks if check.status.upper() == "REVIEW"
        )
        pending = sum(
            1 for check in checks if check.status.upper() == "PENDING"
        )

        # --------------------------------------------------
        # 5. Evaluate Mandatory vs Optional Impact
        # --------------------------------------------------

        mandatory_failed_or_missing = 0
        scorable_total = 0
        scorable_passed = 0

        for check in checks:
            req = getattr(check, "tender_requirement", None)
            if not req and check.tender_requirement_id:
                req = tender_requirement_repository.get_by_id(
                    db, check.tender_requirement_id
                )

            is_req = req.is_required if req is not None else True
            st = check.status.upper()

            if is_req:
                scorable_total += 1
                if st == "PASS":
                    scorable_passed += 1
                elif st in ("FAIL", "MISSING"):
                    mandatory_failed_or_missing += 1
            else:
                # Optional requirements only count if evaluated as PASS or FAIL
                if st == "PASS":
                    scorable_total += 1
                    scorable_passed += 1
                elif st == "FAIL":
                    scorable_total += 1

        # --------------------------------------------------
        # 6. Calculate deterministic compliance score
        # --------------------------------------------------

        if scorable_total > 0:
            score = round(
                (scorable_passed / scorable_total) * 100,
                2,
            )
        else:
            score = 100.0 if passed > 0 else 0.0

        # --------------------------------------------------
        # 7. Determine risk level
        # --------------------------------------------------

        if mandatory_failed_or_missing > 0 or failed > 0:
            risk_level = "HIGH"
        elif missing > 0 or review > 0 or pending > 0:
            risk_level = "MEDIUM"
        elif score >= 80:
            risk_level = "LOW"
        else:
            risk_level = "MEDIUM"

        # --------------------------------------------------
        # 8. Determine overall status
        # --------------------------------------------------

        if mandatory_failed_or_missing > 0 or failed > 0:
            status = "NON_COMPLIANT"
        elif review > 0 or pending > 0:
            status = "REVIEW"
        elif scorable_passed == scorable_total and scorable_total > 0:
            status = "COMPLIANT"
        else:
            status = "REVIEW"

        # --------------------------------------------------
        # 9. Generate summary & metadata
        # --------------------------------------------------

        summary = (
            f"Compliance assessment completed for "
            f"{total_checks} requirement(s): "
            f"{passed} passed, "
            f"{failed} failed, "
            f"{missing} missing, "
            f"{not_applicable} not applicable, "
            f"{review} under review."
        )

        assessment_metadata = {
            "total_checks": total_checks,
            "passed": passed,
            "failed": failed,
            "missing": missing,
            "not_applicable": not_applicable,
            "review": review,
            "pending": pending,
        }

        # --------------------------------------------------
        # 10. Persist or Update assessment
        # --------------------------------------------------

        latest_assessment = (
            compliance_assessment_repository.get_latest_by_submission(
                db, bid_submission_id
            )
        )

        if latest_assessment:
            update_data = ComplianceAssessmentUpdate(
                score=score,
                risk_level=risk_level,
                status=status,
                summary=summary,
                assessment_metadata=assessment_metadata,
                assessed_at=datetime.now(timezone.utc),
            )
            return compliance_assessment_repository.update(
                db, latest_assessment, update_data
            )

        assessment_data = ComplianceAssessmentCreate(
            bid_submission_id=bid_submission_id,
            score=score,
            risk_level=risk_level,
            recommendation=None,
            status=status,
            summary=summary,
            assessment_metadata=assessment_metadata,
            assessed_at=datetime.now(timezone.utc),
        )

        return compliance_assessment_repository.create(
            db,
            assessment_data,
        )


compliance_assessment_service = ComplianceAssessmentService()