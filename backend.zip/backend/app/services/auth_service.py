from sqlalchemy.orm import Session

from app.core.security import create_access_token, verify_password
from app.repositories.user_repository import UserRepository


class AuthService:
    @staticmethod
    def login(
        db: Session,
        email: str,
        password: str,
    ) -> str | None:
        user = UserRepository.get_by_email(db, email)

        if user is None:
            return None

        if not verify_password(
            password,
            user.hashed_password,
        ):
            return None

        return create_access_token(
            user_id=user.id,
            role=user.role,
        )