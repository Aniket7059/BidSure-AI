from app.providers.debarment.mock import MockDebarmentVerificationAdapter
from app.providers.debarment.provider import DebarmentVerificationProvider
from app.providers.digilocker.mock import MockDigiLockerVerificationAdapter
from app.providers.digilocker.provider import DigiLockerVerificationProvider
from app.providers.epfo_esic.mock import MockEPFOESICVerificationAdapter
from app.providers.epfo_esic.provider import EPFOESICVerificationProvider
from app.providers.gst.mock import MockGSTVerificationAdapter
from app.providers.gst.provider import GSTVerificationProvider
from app.providers.gst_return.mock import MockGSTReturnVerificationAdapter
from app.providers.gst_return.provider import GSTReturnVerificationProvider
from app.providers.income_tax.mock import MockIncomeTaxVerificationAdapter
from app.providers.income_tax.provider import IncomeTaxVerificationProvider
from app.providers.make_in_india.mock import MockMakeInIndiaVerificationAdapter
from app.providers.make_in_india.provider import MakeInIndiaVerificationProvider
from app.providers.mca21.mock import MockMCA21VerificationAdapter
from app.providers.mca21.provider import MCA21VerificationProvider
from app.providers.oem_authorization.mock import MockOEMAuthorizationVerificationAdapter
from app.providers.oem_authorization.provider import OEMAuthorizationVerificationProvider
from app.providers.pan.mock import MockPANVerificationAdapter
from app.providers.pan.provider import PANVerificationProvider
from app.providers.registry import provider_registry
from app.providers.startup.mock import MockStartupNSICVerificationAdapter
from app.providers.startup.provider import StartupNSICVerificationProvider
from app.providers.udyam.mock import MockUdyamVerificationAdapter
from app.providers.udyam.provider import UdyamVerificationProvider


def register_providers() -> None:
    """Register verification providers available to the application.

    Development currently uses deterministic mock adapters. Production
    integrations can replace the adapter without changing the provider
    contract, service, or API layer.
    """

    if provider_registry.get("GST_REGISTRATION") is None:
        provider_registry.register(
            GSTVerificationProvider(
                adapter=MockGSTVerificationAdapter(),
            )
        )

    if provider_registry.get("GST_RETURN_FILING") is None:
        provider_registry.register(
            GSTReturnVerificationProvider(
                adapter=MockGSTReturnVerificationAdapter(),
            )
        )

    if provider_registry.get("PAN_VERIFICATION") is None:
        provider_registry.register(
            PANVerificationProvider(
                adapter=MockPANVerificationAdapter(),
            )
        )

    if provider_registry.get("INCOME_TAX_COMPLIANCE") is None:
        provider_registry.register(
            IncomeTaxVerificationProvider(
                adapter=MockIncomeTaxVerificationAdapter(),
            )
        )

    if provider_registry.get("UDYAM_VERIFICATION") is None:
        provider_registry.register(
            UdyamVerificationProvider(
                adapter=MockUdyamVerificationAdapter(),
            )
        )

    if provider_registry.get("MCA21_CORPORATE_CHECK") is None:
        provider_registry.register(
            MCA21VerificationProvider(
                adapter=MockMCA21VerificationAdapter(),
            )
        )

    if provider_registry.get("DEBARMENT_VERIFICATION") is None:
        provider_registry.register(
            DebarmentVerificationProvider(
                adapter=MockDebarmentVerificationAdapter(),
            )
        )

    if provider_registry.get("EPFO_COMPLIANCE") is None:
        provider_registry.register(
            EPFOESICVerificationProvider(
                adapter=MockEPFOESICVerificationAdapter(),
            )
        )

    if provider_registry.get("STARTUP_INDIA_CHECK") is None:
        provider_registry.register(
            StartupNSICVerificationProvider(
                adapter=MockStartupNSICVerificationAdapter(),
            )
        )

    if provider_registry.get("MAKE_IN_INDIA") is None:
        provider_registry.register(
            MakeInIndiaVerificationProvider(
                adapter=MockMakeInIndiaVerificationAdapter(),
            )
        )

    if provider_registry.get("OEM_AUTHORIZATION") is None:
        provider_registry.register(
            OEMAuthorizationVerificationProvider(
                adapter=MockOEMAuthorizationVerificationAdapter(),
            )
        )

    if provider_registry.get("DIGILOCKER_VERIFICATION") is None:
        provider_registry.register(
            DigiLockerVerificationProvider(
                adapter=MockDigiLockerVerificationAdapter(),
            )
        )
