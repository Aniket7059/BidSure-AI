from abc import ABC, abstractmethod

from app.providers.schemas import (
    VerificationRequest,
    VerificationResult,
)


class VerificationProvider(ABC):
    """
    Contract implemented by every verification adapter.

    Providers retrieve/verify facts from a configured source.
    They do not perform tender compliance evaluation, scoring,
    risk classification, or final qualification decisions.
    """

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Stable provider identifier used for persistence and auditing."""
        raise NotImplementedError

    @property
    @abstractmethod
    def supported_verification_types(self) -> set[str]:
        """Verification types handled by this provider."""
        raise NotImplementedError

    def supports(self, verification_type: str) -> bool:
        """Return whether this provider supports the requested verification."""
        return verification_type.upper() in {
            item.upper()
            for item in self.supported_verification_types
        }

    @abstractmethod
    def verify(
        self,
        request: VerificationRequest,
    ) -> VerificationResult:
        """Perform verification and return a normalized result."""
        raise NotImplementedError